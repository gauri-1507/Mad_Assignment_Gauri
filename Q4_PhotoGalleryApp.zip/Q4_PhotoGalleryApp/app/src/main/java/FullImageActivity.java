package com.example.q4_photogalleryapp;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FullImageActivity extends AppCompatActivity {

    ImageView fullImageView;
    TextView tvImageInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image);

        fullImageView = findViewById(R.id.fullImageView);
        tvImageInfo = findViewById(R.id.tvImageInfo);

        String imageUri = getIntent().getStringExtra("imageUri");

        if (imageUri != null) {
            fullImageView.setImageURI(Uri.parse(imageUri));
            tvImageInfo.setText("Image URI: " + imageUri);
        }
    }
}