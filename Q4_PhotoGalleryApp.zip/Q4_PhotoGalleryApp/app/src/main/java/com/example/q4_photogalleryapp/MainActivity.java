package com.example.q4_photogalleryapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnAddImage, btnOpenCamera;
    GridView gridView;
    ArrayList<Uri> imageList;
    ImageAdapter adapter;

    final int IMAGE_REQUEST_CODE = 100;
    final int CAMERA_REQUEST_CODE = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAddImage = findViewById(R.id.btnAddImage);
        btnOpenCamera = findViewById(R.id.btnOpenCamera);
        gridView = findViewById(R.id.gridView);

        imageList = new ArrayList<>();
        adapter = new ImageAdapter(this, imageList);
        gridView.setAdapter(adapter);

        btnAddImage.setOnClickListener(v -> openGallery());
        btnOpenCamera.setOnClickListener(v -> openCamera());

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, FullImageActivity.class);
            intent.putExtra("imageUri", imageList.get(position).toString());
            startActivity(intent);
        });

        gridView.setOnItemLongClickListener((parent, view, position, id) -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Delete Image")
                    .setMessage("Do you want to delete this image?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        imageList.remove(position);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Image Deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_REQUEST_CODE);
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            imageList.add(imageUri);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Image Added from Gallery", Toast.LENGTH_SHORT).show();
        }

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");

            String path = MediaStore.Images.Media.insertImage(
                    getContentResolver(),
                    photo,
                    "Captured_Image",
                    null
            );

            Uri imageUri = Uri.parse(path);
            imageList.add(imageUri);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Image Captured from Camera", Toast.LENGTH_SHORT).show();
        }
    }
}