package com.example.q2_mediaplayerapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnOpenAudio, btnOpenUrl, btnPlay, btnPause, btnStop, btnRestart;
    EditText etVideoUrl;
    VideoView videoView;

    MediaPlayer mediaPlayer;
    Uri audioUri, videoUri;

    final int AUDIO_REQUEST_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOpenAudio = findViewById(R.id.btnOpenAudio);
        btnOpenUrl = findViewById(R.id.btnOpenUrl);
        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
        btnRestart = findViewById(R.id.btnRestart);
        etVideoUrl = findViewById(R.id.etVideoUrl);
        videoView = findViewById(R.id.videoView);

        btnOpenAudio.setOnClickListener(v -> openAudioFile());

        btnOpenUrl.setOnClickListener(v -> {
            String url = etVideoUrl.getText().toString();
            videoUri = Uri.parse(url);
            videoView.setVideoURI(videoUri);
        });

        btnPlay.setOnClickListener(v -> {
            if (mediaPlayer != null) mediaPlayer.start();
            if (videoUri != null) videoView.start();
        });

        btnPause.setOnClickListener(v -> {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) mediaPlayer.pause();
            if (videoView.isPlaying()) videoView.pause();
        });

        btnStop.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer = null;
            }
            if (videoView.isPlaying()) videoView.stopPlayback();
        });

        btnRestart.setOnClickListener(v -> {
            if (mediaPlayer != null) {
                mediaPlayer.seekTo(0);
                mediaPlayer.start();
            }
            if (videoUri != null) {
                videoView.setVideoURI(videoUri);
                videoView.start();
            }
        });
    }

    private void openAudioFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/*");
        startActivityForResult(intent, AUDIO_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AUDIO_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            audioUri = data.getData();
            mediaPlayer = MediaPlayer.create(this, audioUri);
            Toast.makeText(this, "Audio Loaded", Toast.LENGTH_SHORT).show();
        }
    }
}